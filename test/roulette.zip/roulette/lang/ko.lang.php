<?php

	$lang->roulette = "포인트룰렛";
	$lang->roulette_config = "룰렛설정";

	$lang->module_config = "기본설정";
	$lang->log_list = "로그관리";

	$lang->roulette_price = "룰렛구매포인트";
	$lang->today_max_count = "당일참여횟수";
	$lang->today_count_overflow = "룰렛게임은 하루 %d회만 참여 가능합니다.";
	$lang->today_max_count_about = "하루 참여횟수를 제한할수 있습니다. (0 입력시 제한없음)";

	$lang->roulette_receive_message = "당첨금 %d포인트를 수령했습니다.";

	$lang->roulette_fail_message = '꽝입니다. 다음기회에~';

	$lang->roulette_per_overflow = '확률을 조정해주세요.';
	


    // 관리자페이지 -> 로그관리 검색대상
    $lang->roulette_search_target = array(
        "s_data_srl" => "고유번호",
        "s_member_srl" => "회원번호",
        "s_point" => "포인트",
        "s_point_more" => "포인트(이상)",
        "s_point_less" => "포인트(이하)",
        "s_content" => "설명",
        "s_ipaddress" => "IP"
    );

?>