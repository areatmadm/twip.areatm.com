<?php
    /**
     * @class  rouletteModel
     * @brief  roulette 모듈의 Model class
     **/

    class rouletteModel extends module {
        /**
         * @brief 초기화
         **/
        function init() {
        }

        /**
         * @brief 회원의 로그갯수 리턴(오늘)
         **/
        function MyLogCount($member_srl,$category_srl) {
            
			$args = null;
            $args->member_srl = $member_srl;
            $args->category_srl = $category_srl;
            $args->regdate = date("Ymd");

            $output = executeQuery("roulette.getLogCount",$args);
            return (int)$output->data->count;
        }

    }
?>
