    
	// Create new wheel object specifying the parameters at creation time.
	var theWheel = new Winwheel({
		'numSegments'       : 8,                 // Specify number of segments.
		'outerRadius'       : 200,               // Set outer radius so wheel fits inside the background.
		'drawText'          : true,              // Code drawn text can be used with segment images.
		'textFontSize'      : 16,
		'textOrientation'   : 'curved',
		'textAlignment'     : 'inner',
		'textMargin'        : '90',
		'textFontFamily'    : 'monospace',
		'textStrokeStyle'   : 'black',
		'textLineWidth'     : 3,
		'textFillStyle'     : 'white',
		'drawMode'          : 'segmentImage',    // Must be segmentImage to draw wheel using one image per segemnt.
		'segments'          :                    // Define segments including image and text.
		[
		   {'image' : '1'},
		   {'image' : '2'},
		   {'image' : '3'},
		   {'image' : '4'},
		   {'image' : '5'},
		   {'image' : '6'},
		   {'image' : '7'},
		   {'image' : '8'}
		],
		'animation' :           // Specify the animation to use.
		{
			'type'     : 'spinToStop',
			'duration' : 1,     // Duration in seconds.
			'spins'    : 8,     // Number of complete spins.
			'callbackFinished' : 'alertPrize()'
		}
	});
	

